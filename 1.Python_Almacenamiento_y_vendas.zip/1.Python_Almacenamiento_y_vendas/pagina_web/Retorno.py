import sqlite3


class Retorno:

    def exportarproductos(self):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM Producto")
        registros = cursor.fetchall()

        conn.commit()
        conn.close()  # Cierra la conexión
        return registros

    def exportarusuarios(self):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM Cliente")
        registros = cursor.fetchall()

        conn.commit()
        conn.close()  # Cierra la conexión
        return registros

    def registrarusuario(self, usuario, contraseña):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()

        cursor.execute("INSERT INTO cliente (usuario, contraseña) VALUES (?, ?)", (usuario, contraseña))

        conn.commit()
        conn.close()

    def retornarnombreproducto(self, id_producto):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()
        cursor.execute("SELECT nombre, precio FROM Producto WHERE id_producto={}".format(id_producto))

        registros = cursor.fetchall()

        conn.commit()
        conn.close()  # Cierra la conexión
        return registros



    #---------------------------------------SENTENCIAS PARA AGREGAR VENDA
    #METODO PARA SACAR EL MAXIMO
    def sacarDatosOrderby(self, listadenombres, nombretabla, orderby):

        numero_datos = len(listadenombres)
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()

        # mostrar una sola columna
        cursor.execute("SELECT {} FROM {} ORDER BY {} DESC LIMIT 1".format(listadenombres[0], nombretabla, orderby))

        resultados = cursor.fetchall()

        conn.commit()
        conn.close()  # Cierra la conexión
        return resultados[0]

    def sacarProveedorProducto(self, id_producto):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()
        id_producto = int(id_producto)

        cursor.execute("SELECT proveedor FROM Producto WHERE id_producto=?", (id_producto,))

        #cursor.execute("SELECT proveedor FROM Producto WHERE id_producto={}".format(id_producto))


        resultados = cursor.fetchall()

        conn.commit()
        conn.close()  # Cierra la conexión
        return resultados[0]

    #ingresar nueva venda
    def ingresarnuevavenda(self, id_venda, nombre_producto, usuario_cliente, proveedor):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()
        sql = "INSERT INTO Venda (id_venda, nombre_producto, usuario_cliente, proveedor) VALUES (?, ?, ?, ?)"

        cursor.execute(sql, (id_venda, nombre_producto, usuario_cliente, proveedor))

        # No es necesario ejecutar la sentencia SQL otra vez aquí
        # cursor.execute(sql)

        conn.commit()
        conn.close()
    def borrarproducto(self, id_producto):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()

        cursor.execute("DELETE FROM Producto WHERE id_producto = {}".format(id_producto))

        conn.commit()
        conn.close()  # Cierra la conexión

    def retornarocupacionproducto(self, id_producto):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()
        cursor.execute("SELECT ocupacion, id_Almazen FROM Producto WHERE id_producto={}".format(id_producto))

        registros = cursor.fetchall()

        conn.commit()
        conn.close()  # Cierra la conexión
        return registros

    def sumarcapcaidadalmazen(self, id_almazen, ocupacion):
        ruta_basededatos = '../database/base.db'

        conn = sqlite3.connect(ruta_basededatos)
        cursor = conn.cursor()

        cursor.execute("SELECT capacidad FROM Almazen WHERE id_almazen = {}".format(id_almazen))
        capacidad = cursor.fetchone()[0]

        capacidad = capacidad + ocupacion

        cursor.execute("UPDATE Almazen SET capacidad = {} WHERE id_almazen = {}".format(capacidad, id_almazen))


        conn.commit()
        conn.close()  # Cierra la conexión
