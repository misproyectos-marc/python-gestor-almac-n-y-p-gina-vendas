from Retorno import Retorno
from Usuario import Usuario


class Producto:
        #1.crear venda
        #2.eliminar producto
        #3.restar ocupacion
    def agregarVenta(self, nombreproducto, id_producto, usuario):
        retorno = Retorno()


        #sacar el nuevo id_venda
        lista = ["id_venda"]
        ordenado = retorno.sacarDatosOrderby(lista, "Venda", "id_venda")
        id_venda = ordenado[0] + 1

        #saver id prodcuto
        nombreproducto = nombreproducto

        #saver usuario
        usuario = usuario

        #saver proveedor
        proveedor = retorno.sacarProveedorProducto(id_producto)
        provedor = proveedor[0]
        #AGREGAR VENDA
        retorno.ingresarnuevavenda(id_venda, nombreproducto, usuario, provedor)


        #RESTAR OCUPACION DEL ALMAZEN
            #saver ocupacion y almazen
        reg = retorno.retornarocupacionproducto(id_producto)
        print(reg)
        ocupacion = reg[0][0]
        id_almazen = reg[0][1]


        retorno.sumarcapcaidadalmazen(id_almazen, ocupacion)

        # BORRAR PRODUCTO
        retorno.borrarproducto(id_producto)






