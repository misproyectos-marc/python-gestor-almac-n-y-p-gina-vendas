from Retorno import Retorno

class Usuario:
    def __init__(self, usuario, contraseña):
        self.__usuario = usuario
        self.__contraseña = contraseña

    def agregarusuario(self):
        #texto de retorno
        texto = ""
        #saver si el usuario existe:
        retorno = Retorno()
        usuarios = retorno.exportarusuarios()

        #existe = true, ya esta ocupado
        existe = "False"
        for user in usuarios:
            if user[0] == self.__usuario:
                texto ="el usuario ya existe"
                existe = "True"
        if existe == "False":
            retorno.registrarusuario(self.__usuario, self.__contraseña)
            texto = "usuario creado"
        return texto

    def comprovarusuario(self):
        texto = "False"

        retorno = Retorno()
        usuarios = retorno.exportarusuarios()

        for user in usuarios:
            if user[0] == self.__usuario:
                if user[1] == self.__contraseña:
                    texto = "True"
        return texto

    @property
    def retornarusuario(self):
        return self.__usuario

    def agregarProducto(self, id_producto):
        self.productoseleccionados.append()