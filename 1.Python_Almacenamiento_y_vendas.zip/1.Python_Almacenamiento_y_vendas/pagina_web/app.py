import os
import sqlite3

from flask import render_template, request, redirect, url_for, Flask

from Producto import Producto
from Retorno import Retorno
from Usuario import Usuario


app = Flask(__name__)
app.us = "vacio"
app.texto = "vacio"
app.retorno = "vacio"
app.listaproductos = []
#CLASSE INDEX, PRINCIPAL
@app.route('/')
def principal():
    app.listaproductos = []
    retorno = Retorno()
    lista = retorno.exportarproductos()
    return render_template('index.html', list=lista, usuario=app.us)


#RETORNAR LOS PRODUCTOS EN VENDA, RETORNA EL PRODUCTO SELECCIONADO "producto_id
'''
@app.route('/comprar', methods=['POST'])
def comprar_producto():
    producto_id = request.form.get('producto_id')

    retorno = Retorno()
    registro = retorno.retornarnombreproducto(producto_id)
    app.listaproductos.append(registro[0], registro[1])
'''

@app.route('/comprar', methods=['POST'])
def comprar_producto():
    producto_id = request.form.get('producto_id')

    retorno = Retorno()
    registro = retorno.retornarnombreproducto(producto_id)
    nombre_producto = registro[0][0]
    precio_producto = registro[0][1]

    app.listaproductos.append((nombre_producto, precio_producto, producto_id))
    # Renderizar la plantilla 'index.html' nuevamente con la lista de productos actualizada
    retorno = Retorno()
    lista = retorno.exportarproductos()
    return render_template('index.html', list=lista, usuario=app.us)
    #return redirect(url_for('principal'))


#-------------------------------------------------------------------------------------------------
#METODO PARA INICIAR O CREAR USUARIO
@app.route("/iniciar")
def iniciar():
    return render_template('iniciar.html')

#LLAMAR A CREAR USUARIO O INICIAR USUARIO
@app.route('/login', methods=['POST'])
def login():

    if request.form.get('iniciar_sesion'):
        iniciar_sesion(request.form['username'], request.form['password'])
        return app.retorno
    elif request.form.get('crear_sesion'):
        crear_usuario(request.form['username'], request.form['password'])
        return app.texto
    else:
        return "Acción no reconocida"
#INICIAR USUARIO, SI LO HAS INICIADO, IR A LA PAGINA PRINCIPAL COMO USUARIO
def iniciar_sesion(username, password):
    # INICIAR SESION
    username = request.form.get('username')
    password = request.form.get('password')

    usuario = Usuario(username, password)
    resultado = usuario.comprovarusuario()
    if resultado == "True":
        retorno = Retorno()
        lista = retorno.exportarproductos()
        app.retorno = render_template('index.html', list=lista, usuario=app.us)
        app.us = usuario.retornarusuario  # sesion iniciada
        print("se ha ejecutado")
    else:
        app.us = "vacio"  # sesion no iniciada
        print("no se ha ejecutado")
#CREAR USUARIO, SI SE CREA SE AGREGARA A LA BASE DE DATOS
def crear_usuario(username, password):
    # CREAR SESION
    username = request.form.get('username')
    password = request.form.get('password')

    usuario = Usuario(username, password)
    app.texto = usuario.agregarusuario()


#-------------------------------------------------------------------------------------------------
@app.route("/carrito")
def carrito():
    return render_template('carrito.html', carritos=app.listaproductos)

@app.route('/terminar', methods=['POST'])
def efectuar_compra():
    for producto in app.listaproductos:
        product = Producto()
        product.agregarVenta(producto[0], producto[2], app.us) #id_producto, usuario
        print(producto[0])
    return redirect(url_for('principal'))

if __name__ == "__main__":
    app.run(debug=True)