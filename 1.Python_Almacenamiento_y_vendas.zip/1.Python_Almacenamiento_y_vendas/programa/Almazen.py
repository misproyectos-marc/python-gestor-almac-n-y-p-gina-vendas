from Base_De_Datos import Base_De_Datos


class Almazen:
    def __init__(self, id_almazen, localidad, capacidad, capacidadmaxima):
        self.__id_almazen = id_almazen
        self.__localidad = localidad
        self.__capacidad = capacidad
        self.__capacidadmaxima = capacidadmaxima

    # ---------------- seleccionar un almazen por el id, en el constructor solo agregar el id a la isntancia!!!
    def seleccionarAlmazen(self, id_almazen):
        base = Base_De_Datos()
        lista = base.seleccionar("id_almazen", id_almazen, "Almazen")
        self.__id_almazen = id_almazen
        self.__localidad = lista[0][1]
        self.__capacidad = lista[0][2]
        self.__capacidadmaxima = lista[0][3]

    #----------------------------------------------------------------------------------------


    #Getter retornar id almazen
    @property
    def retornarid_almazen(self):
        return self.__id_almazen

    # Getter retornar localidad
    @property
    def retornarlocalidad(self):
        return self.__localidad

    # Getter retornar capacidad
    @property
    def retornarcapacidad(self):
        return self.__capacidad

    # Getter retornar capacidadmaxima
    @property
    def retornarcapacidadmaxima(self):
        return self.__capacidadmaxima
    #----------------------------------------------------------------------------------------

    # Agregar Almazen a la bd
    def agregarAlmazen(self):
        base = Base_De_Datos()
        lista = ["id_almazen", "localidad", "capacidad", "capacidadmaxima"]
        lista2= [self.__id_almazen, self.__localidad, self.__capacidad, self.__capacidadmaxima]
        base.agregarDatos(lista, lista2, "Almazen")

    # Eliminar Trabajador de la bd
    def CerrarAlmazen(self, id_almazen):
        base = Base_De_Datos()
        base.borrarDatos("id_almazen", id_almazen, "Almazen")

    #-------------------------------------------------------------------------------------
    #PRODUCTO NUEVO OCUPA ESPACIO
    def agregarcapacidad(self, ocupacion):
        try:
            self.__capacidad = self.__capacidad + ocupacion
            base = Base_De_Datos()
            #editar capacidad bd
            base.modificar("id_Almazen", self.__id_almazen, "capacidad", self.__capacidad, "Almazen")
        except TypeError as error:
            print("la ocupacion a de ser otro tipo de valor")
    #PRODUCTO SALIDA DEVUELVE EL ESPACIO
    def quitarcapacidad(self, ocupacion):
        self.__capacidad = self.__capacidad - ocupacion
        base = Base_De_Datos()
        #editar capacidad bd
        base.modificar("id_Almazen", self.__id_almazen, "capacidad", self.__capacidad, "Almazen")
        print("valor modificado")
    #-------------------------------------------------------------------------------------

    def detectaralmazenmaslleno(self):
        base = Base_De_Datos()
        almazen = base.almazenmaslleno()
        return almazen
        #[0][0]  idalmazen
        #[0][1]  localidad
        #[0][2]  capacidad
        #[0][3]  capacidadmaxima