from Base_De_Datos import Base_De_Datos
from Proveedor import Proveedor
from Almazen import Almazen
class Producto(Proveedor):
    def __init__(self, id_producto, id_Almazen, nombreEmpresa, telefono, direccion, cif, descuento, iva, porcentaje_ganancia, nombre, descripcion, precio, ocupacion, proveedor):
        super().__init__(nombreEmpresa, telefono, direccion, cif, descuento, iva, porcentaje_ganancia)

        self.__id_producto = id_producto
        self.__id_Almazen = id_Almazen
        self.__nombre = nombre
        self.__descripcion = descripcion
        self.__precio = precio
        self.__ocupacion = ocupacion
        self.__proveedor = nombreEmpresa


    # ---------------- seleccionar un producto por el id, en el constructor solo agregar el id a la isntancia!!!

    def seleccionarProducto(self, id_producto):
        base = Base_De_Datos()
        lista = base.seleccionar("id_producto", id_producto, "Producto")
        self.__id_producto = id_producto
        self.__id_Almazen = lista[0][1]
        self.__nombre = lista[0][2]
        self.__descripcion = lista[0][3]
        self.__precio = lista[0][4]
        self.__ocupacion = lista[0][5]
        self.__proveedor = lista[0][6]

    # ----------------------------------------------------------------------------------------

    # Getter retornar nombre
    @property
    def retornarnombre(self):
        return self.__nombre

     #Getter retornar idproducto
    @property
    def retornaridproducto(self):
        return self.__id_producto

    # ----------------------------------------------------------------------------------------


    # Agregar producto a la bd

    def agregarProducto(self):
        base = Base_De_Datos()
        lista = ["id_producto", "id_Almazen", "nombre", "descripcion", "precio", "ocupacion", "proveedor"]
        lista2 = [self.__id_producto, self.__id_Almazen, self.__nombre, self.__descripcion, self.__precio, self.__ocupacion, self.__proveedor]
        base.agregarDatos(lista, lista2, "Producto")

        #Agregar capacidad
        almazen = Almazen(self.__id_Almazen, "vacio", 0, 0)
        print(self.__id_Almazen)
        almazen.seleccionarAlmazen(self.__id_Almazen)
        almazen.agregarcapacidad(self.__ocupacion)


    # Eliminar Trabajador de la bd

    def venderProducto(self, producto):
        # Quitar capacidad
        almazen = Almazen(producto.__id_Almazen, "vacio", 0, 0)  # agregar el id al almazen
        almazen.seleccionarAlmazen(producto.__id_Almazen)  # buscar el almazen por id
        almazen.quitarcapacidad(producto.__ocupacion)

        base = Base_De_Datos()
        base.borrarDatos("id_producto", producto.__id_producto, "Producto")




    # ----------------------------------------------------------------------------------------


