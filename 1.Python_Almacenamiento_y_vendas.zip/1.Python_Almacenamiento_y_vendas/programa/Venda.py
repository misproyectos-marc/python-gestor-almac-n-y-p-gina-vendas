class Venda:
    def __init__(self, id_venda, id_producto, usuario_cliente, proveedor):
        self.__id_venda = id_venda
        self.__id_producto = id_producto
        self.__usuario_cliente = usuario_cliente
        self.__proveedor = proveedor

    def retornarvendas(self, proveedor):
        print("retonrar")
    '''
    #retornar todas las vendas que hizo un proveedor en concreto
    #sacar el porcentajeganancia de cada producto   ganancia = precio - porcentajeganancia
    #sumar todos las ganancias, asi tendras las ganancias del proveedor x
    '''