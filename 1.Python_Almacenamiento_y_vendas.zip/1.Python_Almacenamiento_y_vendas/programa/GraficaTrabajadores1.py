from tkinter import LabelFrame, Label, ttk, Entry, Tk
from tkinter import LabelFrame, Label, ttk, Entry, Tk

from GraficaAdministrador import GraficaAdministrador
from Grafica_Trabajadores2 import Grafica_Trabajadores2
from Trabajador import Trabajador


class Grafica_Trabajadores1:
    def __init__(self, root):
        self.ventana = root
        self.ventana.title("GESTOR DE PRODUCTOS")
        self.ventana.resizable(1, 1)

        # Creacion del contenedor Frame principal
        frame = LabelFrame(self.ventana, text="REGISTRAR PRODUCTOS")
        frame.grid(row=0, column=0, columnspan=2, pady=100, padx=100)

        # INGRESO USUARIO
        self.etiqueta_usuario = Label(frame, text="USUARIO: ")
        self.etiqueta_usuario.grid(row=0, column=0)

        self.usuario = Entry(frame)
        self.usuario.focus()
        self.usuario.grid(row=0, column=1)

        # INGRESO CONTRASEÑA
        self.etiqueta_contraseña = Label(frame, text="CONTRASEÑA: ")
        self.etiqueta_contraseña.grid(row=1, column=0)

        self.contraseña = Entry(frame)
        self.contraseña.grid(row=1, column=1)

        # BOTON INGRESO
        self.boton_añadir = ttk.Button(frame, text="ACCEDER", command=self.ingresar)
        self.boton_añadir.grid(row=2, column=1)


        # Start the Tkinter main loop
        self.ventana.mainloop()

    def ingresar(self):
        usuario = self.usuario.get()  # usuario retornado de la grafica
        contraseña = self.contraseña.get()  # contraseña retornada de la grafica

        # ha iniciado como admin:
        if usuario == "admin" and contraseña == "admin123":
            self.ventana.destroy()
            root = Tk()
            app = GraficaAdministrador(root)
            root.mainloop()
            print("iniciado como administrador")
        # ha iniciado como trabajador
        else:
            # comprobar que el usuario y la contraseña existan y coincidan
            trabajador = Trabajador("vacio", "vacio", usuario, "vacio")

            retorno = trabajador.comprovarinicio(usuario, contraseña)
            if retorno == "True":
                self.ventana.destroy()
                root = Tk()
                app = Grafica_Trabajadores2(root)
                root.mainloop()

