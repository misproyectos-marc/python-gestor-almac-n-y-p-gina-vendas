from Base_De_Datos import Base_De_Datos


class Proveedor:
    def __init__(self, nombreEmpresa, telefono, direccion, cif, descuento, iva, porcentaje_ganancia):
        self.__nombreEmpresa = nombreEmpresa
        self.__telefono = telefono
        self.__direccion = direccion
        self.__cif = cif
        self.__descuento = descuento
        self.__iva = iva
        self.__porcentaje_ganancia = porcentaje_ganancia

    # ---------------- seleccionar un almazen por el nombreEmpresa, en el constructor solo agregar el nombreEmpresa a la isntancia!!!
    def seleccionarTrabajador(self, nombreEmpresa):
        base = Base_De_Datos()
        lista = base.seleccionar("nombreEmpresa", nombreEmpresa, "Proveedor")
        self.__nombreEmpresa = nombreEmpresa
        self.__telefono = lista[0][1]
        self.__direccion = lista[0][2]
        self.__cif = lista[0][3]
        self.__descuento = lista[0][4]
        self.__iva = lista[0][5]
        self.__porcentaje_ganancia = lista[0][6]
    # ----------------------------------------------------------------------------------------
    # Getter retornar nombreEmpresa
    @property
    def retornarnombreEmpresa(self):
        return self.__nombreEmpresa

    # Getter retornar telefono
    @property
    def retornartelefono(self):
        return self.__telefono

    # Getter retornar direccion
    @property
    def retornardireccion(self):
        return self.__direccion

    # Getter retornar cif
    @property
    def retornarcif(self):
        return self.__cif

    # Getter retornar descuento
    @property
    def retornardescuento(self):
        return self.__descuento

    # Getter retornar iva
    @property
    def retornariva(self):
        return self.__iva
    # ----------------------------------------------------------------------------------------


    # Agregar Almazen a la bd
    def agregarProveedor(self):
        base = Base_De_Datos()
        lista = ["nombreEmpresa", "telefono", "direccion", "cif", "descuento", "iva", "porcentaje_ganancia"]
        lista2 = [self.__nombreEmpresa, self.__telefono, self.__direccion, self.__cif, self.__descuento, self.__iva, self.__porcentaje_ganancia]
        base.agregarDatos(lista, lista2, "Proveedor")

    # Eliminar Trabajador de la bd
    def BorrarProveedor(self, nombreEmpresa):
        base = Base_De_Datos()
        base.borrarDatos("nombreEmpresa", nombreEmpresa, "Proveedor")

    # -------------------------------------------------------------------------------------
    #polimorfismo, avisar proveedor de mal estado o de recarga
    def avisarproveedordañado(self, producto):
        print("Aviso de proveedor enviado, el producto:", producto.retornarnombre, "esta en mal estado")
        producto.venderProducto(producto)  #dinero devuelto
        print("Producto borrado")

    # polimorfismo, pedir mas productos
    def avisarproveedorrecarga(self, producto):
        print("Aviso de proveedor enviado:  producto", producto.retornarnombre, " espera recarga")

