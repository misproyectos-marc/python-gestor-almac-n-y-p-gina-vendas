from Base_De_Datos import Base_De_Datos


class Trabajador:
    def __init__(self, nombre, rango, usuario, contraseña):
        self.__nombre = nombre
        self.__rango = rango
        self.__usuario = usuario
        self.__contraseña = contraseña

    #---------------- seleccionar un trabajador por el nombre, en el constructor solo agregar el nombre a la isntancia!!!
    def seleccionarTrabajador(self, usuario):
        base = Base_De_Datos()
        lista = base.seleccionar("usuario", usuario, "Trabajador")
        self.__nombre = lista[0][0]
        self.__rango = lista[0][1]
        self.__usuario = usuario
        self.__contraseña = lista[0][3]
    #----------------------------------------------------------------------------------------
    #Getter retornar nombre
    @property
    def retornarnombre(self):
        return self.__nombre
    #Getter retornar usuario
    @property
    def retornarusuario(self):
        return self.__usuario

    #Getter retornar contraseña
    @property
    def retornarcontraseña(self):
        return self.__contraseña
    #----------------------------------------------------------------------------------------

    #Agregar trabajador a la bd
    def agregarTrabajador(self):
        base = Base_De_Datos()
        lista = ["nombre", "rango", "usuario", "contraseña"]
        lista2= [self.__nombre, self.__rango, self.__usuario, self.__contraseña]
        base.agregarDatos(lista, lista2, "Trabajador")

    #Eliminar Trabajador de la bd
    def despedirTrabajador(self, usuario):
        base = Base_De_Datos()

        base.borrarDatos("usuario", usuario, "Trabajador")

    #----------------------------------------------------------------------------------------

    def comprovarinicio(self, usuario, contraseña):
        retorno = "False"
        try:
            base = Base_De_Datos()
            lista = base.seleccionar("usuario", usuario, "Trabajador")
            usuariobd = lista[0][2]
            contraseñabd = lista[0][3]

            if usuario == usuariobd and contraseña == contraseñabd:
                retorno = "True"
            else:
                print("error de inicio de sesion")
                retorno = "False"
        except IndexError as e:
                retorno = "False"
                print("error de inicio de sesion")
        return retorno