import os
import sqlite3


class Base_De_Datos:

    def __init__(self):
        # Obtener la ruta del directorio del programa
        ruta_programa = os.path.dirname(__file__)

        # Construir la ruta a la base de datos
        ruta_bd = os.path.join(ruta_programa, '..', 'database', 'base.db')

        self.db = ruta_bd

#METODOS AGREGAR DATOS
    #INSERTAR DATOS
    def agregarDatos(self, listadenombres, listadedatos, nombretabla):
        try:
            numero_datos = len(listadenombres)

            conexion = sqlite3.connect(self.db)
            c = conexion.cursor()

            # agregar una sola columna
            if numero_datos == 1:
                c.execute("INSERT INTO {} ({}) VALUES (?)".format(nombretabla, listadenombres[0]), (listadedatos[0]))

            #agregar dos columnas
            if numero_datos == 2:
                c.execute("INSERT INTO {} ({}, {}) VALUES (?, ?)".format(nombretabla, listadenombres[0], listadenombres[1]),(listadedatos[0], listadedatos[1]))

            #agregar tres columnas
            if numero_datos == 3:
                c.execute("INSERT INTO {} ({}, {}, {}) VALUES (?, ?, ?)".format(nombretabla, listadenombres[0], listadenombres[1], listadenombres[2]), (listadedatos[0], listadedatos[1], listadedatos[2]))

            #agregar cuatro columnas
            if numero_datos == 4:
                c.execute("INSERT INTO {} ({}, {}, {}, {}) VALUES (?, ?, ?, ?)".format(nombretabla, listadenombres[0], listadenombres[1], listadenombres[2], listadenombres[3]), (listadedatos[0], listadedatos[1], listadedatos[2], listadedatos[3]))

            #agregar seis columnas
            if numero_datos == 6:
                c.execute("INSERT INTO {} ({}, {}, {}, {}, {}, {}) VALUES (?, ?, ?, ?, ?, ?)".format(nombretabla, listadenombres[0], listadenombres[1], listadenombres[2], listadenombres[3], listadenombres[4], listadenombres[5]), (listadedatos[0], listadedatos[1], listadedatos[2], listadedatos[3], listadedatos[4], listadedatos[5]))

            #agregar siete columnas
            if numero_datos == 7:
                c.execute("INSERT INTO {} ({}, {}, {}, {}, {}, {}, {}) VALUES (?, ?, ?, ?, ?, ?, ?)".format(nombretabla, listadenombres[0], listadenombres[1], listadenombres[2], listadenombres[3], listadenombres[4], listadenombres[5], listadenombres[6]), (listadedatos[0], listadedatos[1], listadedatos[2], listadedatos[3], listadedatos[4], listadedatos[5], listadedatos[6]))

            conexion.commit()
            c.close()
            conexion.close()
        except sqlite3.IntegrityError as error:
            print("el dato ya existe, prueve otro")
#METODO RETORNAR DATO
    def sacarDatos(self, listadenombres, nombretabla):
        numero_datos = len(listadenombres)

        conexion = sqlite3.connect(self.db)
        c = conexion.cursor()

        # mostrar una sola columna
        if numero_datos == 1:
            c.execute("SELECT {} FROM {}".format( listadenombres[0], nombretabla))

        #mostrar dos columnas
        if numero_datos == 2:
            c.execute("SELECT {}, {} FROM {}".format(listadenombres[0], listadenombres[1], nombretabla))

        # mostrar tres columnas
        if numero_datos == 3:
            c.execute("SELECT {}, {}, {} FROM {}".format(listadenombres[0], listadenombres[1], listadenombres[2], nombretabla))

        # mostrar cuatro columnas
        if numero_datos == 4:
            c.execute("SELECT {}, {}, {}, {} FROM {}".format(listadenombres[0], listadenombres[1], listadenombres[2], listadenombres[3], nombretabla))

        # mostrar cinco columnas
        if numero_datos == 5:
            c.execute("SELECT {}, {}, {}, {}, {} FROM {}".format(listadenombres[0], listadenombres[1], listadenombres[2], listadenombres[3], listadenombres[4], nombretabla))

        # mostrar seis columnas
        if numero_datos == 6:
            c.execute("SELECT {}, {}, {}, {}, {}, {} FROM {}".format(listadenombres[0], listadenombres[1], listadenombres[2], listadenombres[3], listadenombres[4], listadenombres[5], nombretabla))

        #mostrar siete columnas
        if numero_datos == 7:
                c.execute("SELECT {}, {}, {}, {}, {}, {}, {} FROM {}".format(listadenombres[0], listadenombres[1], listadenombres[2], listadenombres[3],listadenombres[4], listadenombres[5], listadenombres[6], nombretabla))

            # Obtener los resultados de la consulta
        resultados = c.fetchall()

        #Cerrar la conexión después de obtener los resultados
        c.close()
        conexion.close()

        return resultados
#METODO BORRAR DATOS
    def borrarDatos(self, nombrecolumnabuscar, valorcolumnabuscar, nombretabla):
        conexion = sqlite3.connect(self.db)
        c = conexion.cursor()
        c.execute("DELETE FROM {} WHERE {} = '{}'".format(nombretabla, nombrecolumnabuscar, valorcolumnabuscar))

        c.close()
        conexion.close()
        print("datos borrados")

#METODO RETORNAR UNO ESPECIFICO, PARA SELECCIONAR
    def seleccionar(self, nombrecolumnabuscar, valorcolumnabuscar, nombretabla):
        conexion = sqlite3.connect(self.db)
        c = conexion.cursor()
        c.execute("SELECT * FROM {} WHERE {} = '{}'".format(nombretabla, nombrecolumnabuscar, valorcolumnabuscar))
        resultados = c.fetchall()

        c.close()
        conexion.close()
        return resultados

#METODO PARA MODIFICAR UN ELEMENTO

    def modificar(self, nombrecolumnabuscar, valorcolumnabuscar, columnamodificar, valorcolumnamodificado, nombretabla):
        conexion = sqlite3.connect(self.db)
        c = conexion.cursor()
        c.execute("UPDATE {} SET {} = '{}' WHERE {} = '{}'".format(nombretabla, columnamodificar, valorcolumnamodificado, nombrecolumnabuscar, valorcolumnabuscar))

        c.close()
        conexion.close()
# METODO PARA SACAR DATO DETERMINADO

    def sacarDatosWhere(self, listadenombres, nombretabla, orderby):
            numero_datos = len(listadenombres)

            conexion = sqlite3.connect(self.db)
            c = conexion.cursor()

            # mostrar una sola columna
            c.execute("SELECT {},{} FROM {} ORDER BY {} DESC LIMIT 1".format(listadenombres[0], listadenombres[1], nombretabla, orderby))

            resultados = c.fetchall()
            c.close()
            conexion.close()
            return resultados
 #METODO PARA SAVER EL ALMAZEN CON MAYOR CAPACIDAD
    def almazenmaslleno(self):

        conexion = sqlite3.connect(self.db)
        c = conexion.cursor()

        # mostrar una sola columna
        c.execute("SELECT id_almazen, localidad, capacidad, capacidadmaxima, (capacidad * 100.0 / capacidadmaxima) AS porcentaje_lleno FROM Almazen ORDER BY porcentaje_lleno DESC LIMIT 1")
        resultados = c.fetchall()
        c.close()
        conexion.close()
        return resultados
