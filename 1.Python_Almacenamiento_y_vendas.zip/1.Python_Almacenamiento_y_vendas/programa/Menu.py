from tkinter import Tk

from Almazen import Almazen
from GraficaTrabajadores1 import Grafica_Trabajadores1
from Producto import Producto
from Proveedor import Proveedor
from Trabajador import Trabajador


class Main:

    if __name__ == '__main__':
        root = Tk()
        grafica = Grafica_Trabajadores1(root)


