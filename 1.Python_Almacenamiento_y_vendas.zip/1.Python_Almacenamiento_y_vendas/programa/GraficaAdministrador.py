from tkinter import LabelFrame, Label, ttk, Entry, Tk, Menu

from Base_De_Datos import Base_De_Datos
from Trabajador import Trabajador


class GraficaAdministrador:
    def __init__(self, root):
        self.ventana = root
        self.ventana.title("ADMINISTRAR TRABAJADORES")
        self.ventana.resizable(1, 1)

        # Creacion del contenedor Frame principal
        texto = "TRABAJADORES"
        frame = LabelFrame(self.ventana, text=texto)
        frame.grid(row=0, column=0, columnspan=2, pady=10, padx=10)  # Ajusté los valores de pady y padx

        # Creación del menú
        menu_bar = Menu(self.ventana)
        self.ventana.config(menu=menu_bar)

        # INGRESAR NOMBRE
        self.etiqueta_nombre = Label(frame, text="NOMBRE: ")
        self.etiqueta_nombre.grid(row=0, column=0)

        self.nombre = Entry(frame)
        self.nombre.focus()
        self.nombre.grid(row=0, column=1)

        # INGRESAR ROL
        self.etiqueta_rango = Label(frame, text="RANGO: ")
        self.etiqueta_rango.grid(row=1, column=0)

        self.rango = Entry(frame)
        self.rango.grid(row=1, column=1)

        # INGRESAR USUARIO
        self.etiqueta_usuario = Label(frame, text="USUARIO: ")
        self.etiqueta_usuario.grid(row=2, column=0)

        self.usuario = Entry(frame)
        self.usuario.grid(row=2, column=1)

        # INGRESAR CONTRASEÑA
        self.etiqueta_contraseña = Label(frame, text="CONTRASEÑA: ")
        self.etiqueta_contraseña.grid(row=3, column=0)

        self.contraseña = Entry(frame)
        self.contraseña.grid(row=3, column=1)

        # BOTON INGRESO
        self.boton_añadir = ttk.Button(frame, text="ACCEDER", command=self.ingresar)
        self.boton_añadir.grid(row=4, column=1)

        # BOTON ELIMINAR
        self.boton_añadir = ttk.Button(frame, text="BOORAR", command=self.borrar)
        self.boton_añadir.grid(row=5, column=1)

        #texto
        self.etiqueta_texto = Label(frame, text="agrege usuario para borrar ")
        self.etiqueta_texto.grid(row=6, column=0)

    def ingresar(self):

        nombre = self.nombre.get()
        rango = self.rango.get()
        usuario = self.usuario.get()
        contraseña = self.contraseña.get()
        trabajador = Trabajador(nombre, rango, usuario, contraseña)
        trabajador.agregarTrabajador()


        self.etiqueta_texto.config(text="trabajador {} ingresado".format(nombre))

        #self.ventana.destroy()
    def borrar(self):
        usuario = self.usuario.get()
        trabajador = Trabajador("vacio", "vacio", usuario, "vacio")
        trabajador.seleccionarTrabajador(usuario)
        print(trabajador)
        trabajador.despedirTrabajador(usuario)

        self.etiqueta_texto.config(text="trabajador {} despedido".format(trabajador.retornarnombre))