from Base_De_Datos import Base_De_Datos
from Producto import Producto


class Cliente:
    def __init__(self, usuario, contraseña):
        self.__usuario = usuario
        self.__contraseña = contraseña


    # ---------------- seleccionar un cliente por el usuario, en el constructor solo agregar el usuario a la isntancia!!!

    def seleccionarProducto(self, usuario):
        base = Base_De_Datos()
        lista = base.seleccionar("usuario", usuario, "Cliente")
        self.__usuario = usuario
        self.__contraseña = lista[0][1]

    # ----------------------------------------------------------------------------------------

    # Agregar producto a la bd

    def agregarCliente(self):
        base = Base_De_Datos()
        lista = ["usuario", "contraseña"]
        lista2 = [self.__usuario, self.__contraseña]
        base.agregarDatos(lista, lista2, "Cliente")


    # Eliminar Trabajador de la bd

    def eliminarCliente(self, usuario):
        base = Base_De_Datos()
        base.borrarDatos("usuario", usuario, "Cliente")

    # ----------------------------------------------------------------------------------------
    #COMPRAR PRODUCTO
    def comprarProducto(self, id_producto):
        producto = Producto(id_producto)
        producto.seleccionarProducto()
        producto.venderProducto(id_producto)


    # ----------------------------------------------------------------------------------------
