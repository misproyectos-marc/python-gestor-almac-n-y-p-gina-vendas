import os
import sqlite3
from tkinter import LabelFrame, Tk, Menu, ttk, Entry, Label

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import Trabajador
from Almazen import Almazen
import matplotlib.pyplot as plt

from Base_De_Datos import Base_De_Datos
from Producto import Producto
from Proveedor import Proveedor


class Grafica_Trabajadores2:
    def __init__(self, root):
        self.ventana = root
        self.ventana.title("GESTOR DE PRODUCTOS")
        self.ventana.resizable(1, 1)

        almazen = Almazen("vacio", "vacio", "vacio", "vacio")
        almazenmax = almazen.detectaralmazenmaslleno()
        texto = "REGISTRAR PRODUCTOS, ALMAZEN MAS LLENO: almazen id: {}".format(almazenmax[0][0])
        texto = "Almazen id: {} ".format(almazenmax[0][0])
        frame = LabelFrame(self.ventana, text=texto)
        frame.grid(row=0, column=0, columnspan=2, pady=300, padx=300)

        # Creación del menú
        menu_bar = Menu(self.ventana)
        self.ventana.config(menu=menu_bar)

        # Menú "Archivo" con opciones
        archivo_menu = Menu(menu_bar, tearoff=0)
        archivo_menu.add_command(label="Agregar Producto", command=self.guardar_producto)
        archivo_menu.add_separator()
        archivo_menu.add_command(label="Agregar Almazen", command=self.guardar_almazen)
        archivo_menu.add_separator()
        archivo_menu.add_command(label="Agregar Proveeidor", command=self.guardar_proveeidor)
        archivo_menu.add_separator()
        archivo_menu.add_command(label="Salir", command=self.ventana.quit)
        menu_bar.add_cascade(label="REGISTRAR ENTRADAS", menu=archivo_menu)


        archivo_menu = Menu(menu_bar, tearoff=1)
        archivo_menu.add_command(label="Eliminar Producto", command=self.eliminar_producto)
        archivo_menu.add_separator()
        archivo_menu.add_command(label="Eliminar Almazen", command=self.eliminar_producto)
        archivo_menu.add_separator()
        archivo_menu.add_command(label="Eliminar Proveeidor", command=self.eliminar_producto)
        archivo_menu.add_separator()
        menu_bar.add_cascade(label="BORRAR ENTRADAS", menu=archivo_menu)

        archivo_menu = Menu(menu_bar, tearoff=2)
        archivo_menu.add_command(label="Grafica Proveedores", command=self.GraficaProvedores)
        archivo_menu.add_separator()
        archivo_menu.add_command(label="Grafica Productos", command=self.GraficaProductos)
        archivo_menu.add_separator()
        menu_bar.add_cascade(label="OTROS GRAFICOS", menu=archivo_menu)

        # Calcular el porcentaje de la capacidad ocupada en comparación con la capacidad máxima
        porcentaje_ocupado = (almazenmax[0][2] / almazenmax[0][3]) * 100

        fig, ax = plt.subplots()
        ax.bar(["Capacidad Ocupada", "Capacidad Restante"], [porcentaje_ocupado, 100 - porcentaje_ocupado])
        ax.set_ylabel("Porcentaje de Almacén {}".format(almazenmax[0][1]))

        # Crear un widget Canvas para integrar el gráfico en la ventana Tkinter
        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.draw()
        canvas.get_tk_widget().grid(row=3, columnspan=2)


    #AGREGAR NUEVO PRODUCTO
    def guardar_producto(self):
        ventana_producto = Guardar_Producto()

    #AGREGAR NEUVO ALMAZEN
    def guardar_almazen(self):
        ventana_almazen = Guardar_Almazen()

    #AGREGAR NUEVO PROVEIDOR
    def guardar_proveeidor(self):
        ventana_proveeidor = Guardar_Proveeidor()

    #ELIMINAR UN PRODUCTO
    def eliminar_producto(self):
        ventana_producto = Borrar_Producto()


    #ELIMINAR UN ALAMZEN
    def eliminar_almazen(self):
        ventana_almazen = Borrar_Almazen()

    #ELIMINAR UN PROVEIDOR

    def eliminar_proveeidor(self):
        ventana_proveeidor = Borrar_Proveidor()

    #CREAR GRAFICA DE ESTADISTICAS DE LOS PROVEIDORES

    def GraficaProvedores(self):
        ventanaGraficaProvedor = GraficaProvedor()

    #CREAR GRAFICA DE ESTADISTICAS DE LOS PRODUCTOS
    def GraficaProductos(self):
        ventanaGraficaProducto = GraficaProducto()



'''
        # Calcular el porcentaje de la capacidad ocupada en comparación con la capacidad máxima
        porcentaje_ocupado = (almazen.retornar_capacidad / almazen.retornar_capacidadmaxima) * 100

        fig, ax = plt.subplots()
        ax.bar(["Capacidad Ocupada", "Capacidad Restante"], [porcentaje_ocupado, 100 - porcentaje_ocupado])
        ax.set_ylabel("Porcentaje de Almacén Ocupado")

        # Crear un widget Canvas para integrar el gráfico en la ventana Tkinter
        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.draw()
        canvas.get_tk_widget().grid(row=3, columnspan=2)
'''

#AGREGAR PRODUCTO
class Guardar_Producto:
    def __init__(self):
        self.ventana_producto = Tk()
        self.ventana_producto.title("Agregar Producto")
        self.ventana_producto.resizable(2, 1)

        # Creacion del contenedor Frame principal
        frame = LabelFrame(self.ventana_producto, text="REGISTRAR PRODUCTO")
        frame.grid(row=0, column=0, columnspan=2, pady=30, padx=10)



        self.idAlmazen_label = Label(frame, text="ID Almazen:")
        self.idAlmazen_label.grid(row=0, column=0)
        self.idAlmazen = Entry(frame)
        self.idAlmazen.grid(row=0, column=1)

        self.nombre_label = Label(frame, text="Nombre:")
        self.nombre_label.grid(row=1, column=0)
        self.nombre = Entry(frame)
        self.nombre.focus()
        self.nombre.grid(row=1, column=1)

        self.descripcion_label = Label(frame, text="Descripción:")
        self.descripcion_label.grid(row=2, column=0)
        self.descripcion = Entry(frame)
        self.descripcion.grid(row=2, column=1)

        self.precio_label = Label(frame, text="Precio:")
        self.precio_label.grid(row=3, column=0)
        self.precio = Entry(frame)
        self.precio.grid(row=3, column=1)

        self.ocupacion_label = Label(frame, text="Ocupación:")
        self.ocupacion_label.grid(row=4, column=0)
        self.ocupacion = Entry(frame)
        self.ocupacion.grid(row=4, column=1)

        self.proveedor_label = Label(frame, text="Nombre Proveedor:")
        self.proveedor_label.grid(row=5, column=0)
        self.proveedor = Entry(frame)
        self.proveedor.grid(row=5, column=1)

        self.boton_añadir = ttk.Button(frame, text="Guardar Producto", command=self.guardar_producto)
        self.boton_añadir.grid(row=6, columnspan=2)

        # texto
        self.etiqueta_texto = Label(frame, text="agregue los datos del producto ")
        self.etiqueta_texto.grid(row=7, column=0)

        # Iniciar el bucle principal de la ventana
        self.ventana_producto.mainloop()


    def guardar_producto(self):
        try:
            #id_producto = self.id_producto.get()
            id_almazen = self.idAlmazen.get()
            nombre = self.nombre.get()
            descripcion = self.descripcion.get()
            precio = self.precio.get()
            ocupacion = self.ocupacion.get()
            nombre_proveedor = self.proveedor.get()


            base = Base_De_Datos()
            #retornar los datos proveedor en una lista
            proveedor = base.seleccionar("nombreEmpresa", nombre_proveedor, "Proveedor")

            #retornar el nombre del producto con el id mas alto
            lista = ["nombre", "id_producto"]
            ultimo = base.sacarDatosWhere(lista, "Producto", "id_producto")
            ultimoid = ultimo[0][1]
            nuevoid = ultimoid +1

            #crear nuevo producto
            producto = Producto(nuevoid, id_almazen, proveedor[0][0], proveedor[0][1], proveedor[0][2], proveedor[0][3],
                                proveedor[0][4], proveedor[0][5], nombre, descripcion, precio, ocupacion, proveedor[0][0], proveedor[0][6])
            #agregar productobd
            producto.agregarProducto()

            #cambiar el texto
            self.etiqueta_texto.config(text="producto agregado correctamente, id: {}".format(nuevoid))

        except IndexError as error:
            self.etiqueta_texto.config(text="algun elemento es erroneo, vuelve a intentarlo")
#AGREGAR ALMAZEN
class Guardar_Almazen:
    def __init__(self):
        self.ventana_producto = Tk()
        self.ventana_producto.title("Agregar Almazen")
        self.ventana_producto.resizable(2, 1)

        # Creacion del contenedor Frame principal
        frame = LabelFrame(self.ventana_producto, text="REGISTRAR PRODUCTO")
        frame.grid(row=0, column=0, columnspan=2, pady=20, padx=10)

        self.localidad = Label(frame, text="Localidad:")
        self.localidad.grid(row=1, column=0)
        self.localidad = Entry(frame)
        self.localidad.grid(row=1, column=1)

        self.capacidad = Label(frame, text="Capacidad:")
        self.capacidad.grid(row=2, column=0)
        self.capacidad = Entry(frame)
        self.capacidad.grid(row=2, column=1)

        self.capacidadmaxim = Label(frame, text="Capacidad Maxima:")
        self.capacidadmaxim.grid(row=3, column=0)
        self.capacidadmaxim = Entry(frame)
        self.capacidadmaxim.grid(row=3, column=1)

        self.boton_añadir = ttk.Button(frame, text="Guardar Almazen", command=self.guardar_almazen)
        self.boton_añadir.grid(row=6, columnspan=2)

        self.etiqueta_texto = Label(frame, text="agregue los datos del almazen ")
        self.etiqueta_texto.grid(row=7, column=0)

        # Iniciar el bucle principal de la ventana
        self.ventana_producto.mainloop()

    def guardar_almazen(self):
        localidad = self.localidad.get()
        capacidad = self.capacidad.get()
        capacidadmaxima = self.capacidadmaxim.get()

        #sacar el nuevo id en la variable nuevoid
        lista = ["localidad", "id_almazen"]
        base = Base_De_Datos()
        ultimo = base.sacarDatosWhere(lista, "Almazen", "id_almazen")
        ultimoid = ultimo[0][1]
        nuevoid = ultimoid +1
        #crear nuevo almazen
        almazen = Almazen(nuevoid, localidad, capacidad, capacidadmaxima)
        almazen.agregarAlmazen()
        self.etiqueta_texto.config(text="almazen agregado correctamente, id: {}".format(nuevoid))

#AGREGAR PROVEIDOR
class Guardar_Proveeidor:
    def __init__(self):
        self.ventana_producto = Tk()
        self.ventana_producto.title("Agregar Proveeidor")
        self.ventana_producto.resizable(2, 1)

        # Creacion del contenedor Frame principal
        frame = LabelFrame(self.ventana_producto, text="REGISTRAR PRODUCTO")
        frame.grid(row=0, column=0, columnspan=2, pady=20, padx=10)

        self.nombreEmpresa = Label(frame, text="Nombre Empresa:")
        self.nombreEmpresa.grid(row=0, column=0)
        self.nombreEmpresa = Entry(frame)
        self.nombreEmpresa.focus()
        self.nombreEmpresa.grid(row=0, column=1)

        self.telefono = Label(frame, text="Telefono:")
        self.telefono.grid(row=1, column=0)
        self.telefono = Entry(frame)
        self.telefono.grid(row=1, column=1)

        self.direccion = Label(frame, text="Direccion:")
        self.direccion.grid(row=2, column=0)
        self.direccion = Entry(frame)
        self.direccion.grid(row=2, column=1)

        self.cif = Label(frame, text="Cif:")
        self.cif.grid(row=3, column=0)
        self.cif = Entry(frame)
        self.cif.grid(row=3, column=1)

        self.descuento = Label(frame, text="Descuento:")
        self.descuento.grid(row=4, column=0)
        self.descuento = Entry(frame)
        self.descuento.grid(row=4, column=1)

        self.iva = Label(frame, text="Iva:")
        self.iva.grid(row=5, column=0)
        self.iva = Entry(frame)
        self.iva.grid(row=5, column=1)

        self.porcentaje_ganancia = Label(frame, text="Porcentaje Ganancia")
        self.porcentaje_ganancia.grid(row=6, column=0)
        self.porcentaje_ganancia = Entry(frame)
        self.porcentaje_ganancia.grid(row=6, column=1)

        self.boton_añadir = ttk.Button(frame, text="Guardar Proveedor", command=self.guardar_proveedor)
        self.boton_añadir.grid(row=7, columnspan=2)

        self.etiqueta_texto = Label(frame, text="agregue los datos del proveedor ")
        self.etiqueta_texto.grid(row=8, column=0)


        # Iniciar el bucle principal de la ventana
        self.ventana_producto.mainloop()

    def guardar_proveedor(self):
        nombreEmpresa = self.nombreEmpresa.get()
        telefono = self.telefono.get()
        direccion = self.direccion.get()
        cif = self.cif.get()
        descuento = self.descuento.get()
        iva = self.iva.get()
        porcentaje_ganancia= self.porcentaje_ganancia.get()

        #crear nuevo proveedor
        proveedor = Proveedor(nombreEmpresa, telefono, direccion, cif, descuento, iva, porcentaje_ganancia)
        #agregar proveedorbd
        proveedor.agregarProveedor()
        self.etiqueta_texto.config(text="proveedor agregado correctamente, nombre: {}".format(nombreEmpresa))
#BORRAR PRODUCTO
class Borrar_Producto():
    def __init__(self):
        self.ventana_producto = Tk()
        self.ventana_producto.title("Borrar Producto")
        self.ventana_producto.resizable(2, 1)

        # Creacion del contenedor Frame principal
        frame = LabelFrame(self.ventana_producto, text="BORRAR PRODUCTO")
        frame.grid(row=0, column=0, columnspan=2, pady=20, padx=10)

        self.id = Label(frame, text="ID PRODUCTO:")
        self.id.grid(row=1, column=0)
        self.id = Entry(frame)
        self.id.grid(row=1, column=1)

        self.boton_añadir = ttk.Button(frame, text="Borrar Producto", command=self.borrar_producto)
        self.boton_añadir.grid(row=2, columnspan=2)



        self.etiqueta_texto = Label(frame, text="INTRODUZCA EL ID DEL PRODUCTO")
        self.etiqueta_texto.grid(row=3, column=0)

        self.ventana_producto.mainloop()


    def borrar_producto(self):
        id = self.id.get()
        base = Base_De_Datos()
        base.borrarDatos("id_producto", id, "Producto")
        self.etiqueta_texto.config(text="PRODUCTO {} BORRADO".format(id))
#BORRAR ALMAZEN
class Borrar_Almazen():
    def __init__(self):
        self.ventana_producto = Tk()
        self.ventana_producto.title("Borrar Almazen")
        self.ventana_producto.resizable(2, 1)

        # Creacion del contenedor Frame principal
        frame = LabelFrame(self.ventana_producto, text="BORRAR PRODUCTO")
        frame.grid(row=0, column=0, columnspan=2, pady=20, padx=10)

        self.id = Label(frame, text="ID Almazen:")
        self.id.grid(row=1, column=0)
        self.id = Entry(frame)
        self.id.grid(row=1, column=1)

        self.boton_añadir = ttk.Button(frame, text="Borrar Almazen", command=self.borrar_almazen)
        self.boton_añadir.grid(row=2, columnspan=2)

        self.etiqueta_texto = Label(frame, text="INTRODUZCA EL ID DEL ALMAZEN")
        self.etiqueta_texto.grid(row=3, column=0)

        self.ventana_producto.mainloop()

    def borrar_almazen(self):
        id = self.id.get()
        base = Base_De_Datos()
        base.borrarDatos("id_almazen", id, "Almazen")
        self.etiqueta_texto.config(text="ALMAZEN {} BORRADO".format(id))
#BORRAR PROVEIDOR
class Borrar_Proveidor():
    def __init__(self):
        self.ventana_producto = Tk()
        self.ventana_producto.title("Borrar Proveedor")
        self.ventana_producto.resizable(2, 1)

        # Creacion del contenedor Frame principal
        frame = LabelFrame(self.ventana_producto, text="BORRAR PRODUCTO")
        frame.grid(row=0, column=0, columnspan=2, pady=20, padx=10)

        self.id = Label(frame, text="nombre proveedor:")
        self.id.grid(row=1, column=0)
        self.id = Entry(frame)
        self.id.grid(row=1, column=1)

        self.boton_añadir = ttk.Button(frame, text="Borrar Proveedor", command=self.borrar_proveedor)
        self.boton_añadir.grid(row=2, columnspan=2)

        self.etiqueta_texto = Label(frame, text="INTRODUZCA EL NOMBRE DEL PROVEEDOR")
        self.etiqueta_texto.grid(row=3, column=0)

        self.ventana_producto.mainloop()

    def borrar_proveedor(self):
        id = self.id.get()
        base = Base_De_Datos()
        base.borrarDatos("nombreEmpresa", id, "Proveedor")
        self.etiqueta_texto.config(text="PROVEEDOR {} BORRADO".format(id))


# GRAFICA ESTADISTICA DE PRODUCTOS
class GraficaProducto:
    def __init__(self):
        self.ventana_producto = Tk()
        self.ventana_producto.title("PRODUCTOS MAS VENDIDOS")
        self.ventana_producto.resizable(2, 1)

        # Creacion del contenedor Frame principal
        frame = LabelFrame(self.ventana_producto, text="PRODUCTOS MAS VENDIDOS")
        frame.grid(row=0, column=0, columnspan=2, pady=20, padx=10)

        # RUTA BD
        ruta_programa = os.path.dirname(__file__)
        ruta_bd = os.path.join(ruta_programa, '..', 'database', 'base.db')

        # Conectar a la base de datos
        conn = sqlite3.connect(ruta_bd)
        cursor = conn.cursor()

        # Consulta para obtener los datos de los productos más vendidos
        cursor.execute(
            "SELECT nombre_producto, COUNT(*) as total_vendido FROM Venda GROUP BY nombre_producto ORDER BY total_vendido DESC")
        resultados = cursor.fetchall()

        # Separar los nombres de los productos y el total vendido en listas separadas
        productos = [resultado[0] for resultado in resultados]
        total_vendido = [resultado[1] for resultado in resultados]

        # Cerrar la conexión a la base de datos
        conn.close()

        # Crear el gráfico
        fig = plt.figure(figsize=(10, 6))
        plt.bar(productos, total_vendido, color='skyblue')
        plt.xlabel('Producto')
        plt.ylabel('Total Vendido')
        plt.title('Productos Más Vendidos')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()

        # Crear un lienzo de la figura de Matplotlib para Tkinter
        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.draw()
        canvas.get_tk_widget().pack()

        # Mostrar la ventana principal
        self.ventana_producto.mainloop()

class GraficaProvedor:
    def __init__(self):
        self.ventana_proveedor = Tk()
        self.ventana_proveedor.title("PROVEEDORES MÁS VENDIDOS")
        self.ventana_proveedor.resizable(2, 1)

        # Creación del contenedor Frame principal
        frame = LabelFrame(self.ventana_proveedor, text="PROVEEDORES MÁS VENDIDOS")
        frame.grid(row=0, column=0, columnspan=2, pady=20, padx=10)

        # Ruta de la base de datos
        ruta_programa = os.path.dirname(__file__)
        ruta_bd = os.path.join(ruta_programa, '..', 'database', 'base.db')

        # Conexión a la base de datos
        conn = sqlite3.connect(ruta_bd)
        cursor = conn.cursor()

        # Consulta para obtener los datos de los proveedores más vendidos
        cursor.execute(
            "SELECT proveedor, COUNT(*) as total_vendido FROM Venda GROUP BY proveedor ORDER BY total_vendido DESC")
        resultados = cursor.fetchall()

        # Separar los nombres de los proveedores y el total vendido en listas separadas
        proveedores = [resultado[0] for resultado in resultados]
        total_vendido = [resultado[1] for resultado in resultados]

        # Cerrar la conexión a la base de datos
        conn.close()

        # Crear el gráfico
        fig = plt.figure(figsize=(10, 6))
        plt.bar(proveedores, total_vendido, color='skyblue')
        plt.xlabel('Proveedor')
        plt.ylabel('Total Vendido')
        plt.title('Proveedores Más Vendidos')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()

        # Crear un lienzo de la figura de Matplotlib para Tkinter
        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.draw()
        canvas.get_tk_widget().pack()

        # Mostrar la ventana principal
        self.ventana_proveedor.mainloop()